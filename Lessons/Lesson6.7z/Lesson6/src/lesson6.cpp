#include <cmath>
#include <string>
#include "lesson6.hpp"

using namespace std;

