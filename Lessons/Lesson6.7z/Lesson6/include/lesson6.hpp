#ifndef _LESSON6_HPP_
#define _LESSON6_HPP_

#include <cstdint>
#include <string>
#include <cassert>

using namespace std;

#endif // !_LESSON6_HPP_
